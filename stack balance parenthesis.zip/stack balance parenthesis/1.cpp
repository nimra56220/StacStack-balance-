#include <iostream>
#include <stack>
#include <string>

bool areParenthesesBalanced(const std::string &expression) {
    std::stack<char> st;
    
    for (char ch : expression) {
        if (ch == '(' || ch == '{' || ch == '[') {
            st.push(ch);
        } else if (ch == ')' || ch == '}' || ch == ']') {
            if (st.empty()) {
                return false;  // Unmatched closing parenthesis
            }

            char top = st.top();
            st.pop();
            
            if ((ch == ')' && top != '(') || (ch == '}' && top != '{') || (ch == ']' && top != '[')) {
                return false;  // Mismatched opening and closing parenthesis
            }
        }
    }
    
    return st.empty();  // Stack should be empty for balanced parentheses
}

int main() {
    std::string expression;
    std::cout << "Enter an expression with parentheses: ";
    std::cin >> expression;
    
    if (areParenthesesBalanced(expression)) {
        std::cout << "Parentheses are balanced." << std::endl;
    } else {
        std::cout << "Parentheses are not balanced." << std::endl;
    }
    
    return 0;
} 
Stack balance parenthesis